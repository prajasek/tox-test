import pytest 
def add(a, b):
    return a+b